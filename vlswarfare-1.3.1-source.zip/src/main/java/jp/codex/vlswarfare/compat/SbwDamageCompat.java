package jp.codex.vlswarfare.compat;

import net.minecraft.core.RegistryAccess;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import java.lang.reflect.Method;

/** Bridges VLS impacts into Superb Warfare's vehicle health and damage-type system. */
public final class SbwDamageCompat {
    private static boolean resolved;
    private static Class<?> vehicleClass;
    private static Method projectileDamageSource;
    private static Method explosionDamageSource;
    private static Method getHealth;
    private static Method setHealth;

    public static boolean isVehicle(Entity entity) {
        resolve();
        return vehicleClass != null && vehicleClass.isInstance(entity);
    }

    public static boolean hurtVehicle(Entity target, Entity direct, Entity attacker, float damage, boolean explosion) {
        if (!isVehicle(target)) return false;
        try {
            float before = ((Number)getHealth.invoke(target)).floatValue();
            Method factory = explosion ? explosionDamageSource : projectileDamageSource;
            DamageSource source = (DamageSource)factory.invoke(null, target.level().registryAccess(), direct, attacker);
            target.hurt(source, damage);
            float after = ((Number)getHealth.invoke(target)).floatValue();
            // Some SBW armor profiles reduce unknown/add-on hits to zero. Guarantee the configured vehicle damage.
            if (after >= before - 0.01f) setHealth.invoke(target, before - damage);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return fallbackHealth(target, damage);
        }
    }

    public static void hurtVehiclesInRadius(Level level, Entity direct, Entity primary, double radius, float damage) {
        AABB area = new AABB(direct.position(), direct.position()).inflate(radius);
        for (Entity vehicle : level.getEntities(direct, area, SbwDamageCompat::isVehicle)) {
            if (vehicle == primary) continue;
            double distance = vehicle.getBoundingBox().getCenter().distanceTo(direct.position());
            float falloff = (float)Math.max(0.2, 1.0 - distance / Math.max(1.0, radius));
            hurtVehicle(vehicle, direct, direct instanceof Projectile projectile ? projectile.getOwner() : null, damage * falloff, true);
        }
    }

    private static boolean fallbackHealth(Entity target, float damage) {
        try {
            float health = ((Number)getHealth.invoke(target)).floatValue();
            setHealth.invoke(target, health - damage);
            return true;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    private static synchronized void resolve() {
        if (resolved) return;
        resolved = true;
        try {
            vehicleClass = Class.forName("com.atsuishio.superbwarfare.entity.vehicle.base.VehicleEntity");
            Class<?> damageTypes = Class.forName("com.atsuishio.superbwarfare.init.ModDamageTypes");
            projectileDamageSource = damageTypes.getMethod("causeProjectileHitDamage", RegistryAccess.class, Entity.class, Entity.class);
            explosionDamageSource = damageTypes.getMethod("causeCustomExplosionDamage", RegistryAccess.class, Entity.class, Entity.class);
            getHealth = vehicleClass.getMethod("getHealth");
            setHealth = vehicleClass.getMethod("setHealth", float.class);
        } catch (ReflectiveOperationException ignored) {
            vehicleClass = null;
        }
    }

    private SbwDamageCompat() {}
}
