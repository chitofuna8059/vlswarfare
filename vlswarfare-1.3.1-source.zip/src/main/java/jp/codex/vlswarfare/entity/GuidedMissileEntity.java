package jp.codex.vlswarfare.entity;

import jp.codex.vlswarfare.VlsConfig;
import jp.codex.vlswarfare.compat.SbwDamageCompat;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import java.util.UUID;
import java.lang.reflect.Method;

public final class GuidedMissileEntity extends Projectile {
    private static final EntityDataAccessor<Integer> MISSILE_TYPE = SynchedEntityData.defineId(GuidedMissileEntity.class, EntityDataSerializers.INT);
    private UUID targetUuid;
    private Vec3 targetPoint = Vec3.ZERO;
    private int life;
    private static Method sbwChunkLoader;
    private static boolean chunkLoaderResolved;

    public GuidedMissileEntity(EntityType<? extends GuidedMissileEntity> type, Level level) { super(type, level); noCulling = true; }
    @Override protected void defineSynchedData() { entityData.define(MISSILE_TYPE, 0); }

    public void configure(int missileType, Entity target, Vec3 point) {
        entityData.set(MISSILE_TYPE, missileType); targetUuid = target == null ? null : target.getUUID(); targetPoint = point;
        setDeltaMovement(0, VlsConfig.LAUNCH_SPEED.get() / 20.0, 0);
        level().playSound(null, blockPosition(), SoundEvents.DISPENSER_LAUNCH, SoundSource.BLOCKS, 1.8f, 0.55f);
    }
    public int getMissileType() { return entityData.get(MISSILE_TYPE); }
    public boolean isInterceptor() { return getMissileType() == 1; }
    public boolean isNuclear() { return getMissileType() == 2; }

    @Override public void tick() {
        super.tick(); life++;
        if (level().isClientSide) { spawnTrail(); return; }
        Vec3 start = position();
        Entity target = targetUuid != null && level() instanceof ServerLevel sl ? sl.getEntity(targetUuid) : null;
        Vec3 proximityTarget = targetPoint;
        if (target != null && target.isAlive()) {
            proximityTarget = target.getBoundingBox().getCenter();
            double cruisePerTick = Math.max(0.05, VlsConfig.MISSILE_SPEED.get() / 20.0);
            double leadTicks = Math.min(40.0, position().distanceTo(proximityTarget) / cruisePerTick);
            targetPoint = proximityTarget.add(target.getDeltaMovement().scale(leadTicks));
        }
        int verticalTicks = VlsConfig.VERTICAL_LAUNCH_TICKS.get();
        int accelerationTicks = VlsConfig.ACCELERATION_TICKS.get();
        double launchSpeed = VlsConfig.LAUNCH_SPEED.get() / 20.0;
        double cruiseSpeed = VlsConfig.MISSILE_SPEED.get() / 20.0;
        Vec3 velocity;
        if (life <= verticalTicks) {
            velocity = new Vec3(0, launchSpeed, 0);
        } else {
            if (life == verticalTicks + 1) level().playSound(null, blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.BLOCKS, 3.0f, 0.65f);
            double progress = Math.min(1.0, (life - verticalTicks) / (double) accelerationTicks);
            double eased = progress * progress * (3.0 - 2.0 * progress);
            double speed = launchSpeed + (cruiseSpeed - launchSpeed) * eased;
            Vec3 delta = targetPoint.subtract(position());
            Vec3 desired = delta.lengthSqr() < 1.0e-6 ? getDeltaMovement().normalize() : delta.normalize();
            double distance = position().distanceTo(targetPoint);
            double closeCorrection = Math.max(0.0, Math.min(0.45, (80.0 - distance) / 160.0));
            double guidance = 0.08 + 0.34 * progress + closeCorrection;
            Vec3 steered = getDeltaMovement().normalize().scale(1.0 - guidance).add(desired.scale(guidance));
            velocity = (steered.lengthSqr() < 1.0e-6 ? desired : steered.normalize()).scale(speed);
        }
        setDeltaMovement(velocity);
        hasImpulse = true;
        Vec3 end = start.add(velocity);
        if (level() instanceof ServerLevel server) keepFlightChunkLoaded(server, end);
        BlockHitResult blockHit = level().clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        Vec3 closest = closestPointOnSegment(proximityTarget, start, end);
        boolean withinAccuracy = life > verticalTicks && closest.distanceToSqr(proximityTarget) <= 25.0;
        if (blockHit.getType() != HitResult.Type.MISS || withinAccuracy) {
            Vec3 impact = blockHit.getType() != HitResult.Type.MISS ? blockHit.getLocation() : closest;
            setPos(impact.x, impact.y, impact.z); detonate(target); return;
        }
        setPos(end.x, end.y, end.z);
        setYRot((float)(Math.atan2(velocity.z, velocity.x) * 180 / Math.PI) - 90f);
        setXRot((float)(-Math.atan2(velocity.y, Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z)) * 180 / Math.PI));
        if (life > 20 * 120 || position().distanceTo(targetPoint) > VlsConfig.RADAR_RANGE.get() * 1.5) discard();
    }
    private static Vec3 closestPointOnSegment(Vec3 point, Vec3 start, Vec3 end) {
        Vec3 segment = end.subtract(start);
        double lengthSq = segment.lengthSqr();
        if (lengthSq < 1.0e-9) return start;
        double t = Math.max(0.0, Math.min(1.0, point.subtract(start).dot(segment) / lengthSq));
        return start.add(segment.scale(t));
    }
    private void spawnTrail() {
        Vec3 velocity = getDeltaMovement();
        int samples = Math.max(3, Math.min(24, (int)Math.ceil(velocity.length() * 2.0)));
        for (int i = 0; i < samples; i++) {
            double t = i / (double)samples;
            double x = getX() - velocity.x * t, y = getY() - velocity.y * t, z = getZ() - velocity.z * t;
            level().addParticle(i % 4 == 0 ? ParticleTypes.FLAME : ParticleTypes.SMOKE, x, y, z, 0, 0.01, 0);
        }
        if (life <= VlsConfig.VERTICAL_LAUNCH_TICKS.get()) level().addParticle(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, getX(), getY() - .8, getZ(), 0, .03, 0);
    }
    @Override public boolean shouldRenderAtSqrDistance(double distance) { return distance < 1024.0 * 1024.0; }
    private static void keepFlightChunkLoaded(ServerLevel level, Vec3 next) {
        ChunkPos chunk = new ChunkPos(net.minecraft.core.BlockPos.containing(next));
        try {
            if (!chunkLoaderResolved) {
                chunkLoaderResolved = true;
                Class<?> manager = Class.forName("com.atsuishio.superbwarfare.world.saveddata.ProjectileChunkSavedData");
                sbwChunkLoader = manager.getMethod("queueForceLoad", ServerLevel.class, ChunkPos.class);
            }
            if (sbwChunkLoader != null) sbwChunkLoader.invoke(null, level, chunk);
            else level.getChunk(chunk.x, chunk.z);
        } catch (ReflectiveOperationException ignored) {
            sbwChunkLoader = null;
            level.getChunk(chunk.x, chunk.z);
        }
    }
    private void detonate(Entity target) {
        if (!level().isClientSide) {
            double damage = isNuclear() ? VlsConfig.NUCLEAR_DAMAGE.get() : isInterceptor() ? VlsConfig.INTERCEPT_DAMAGE.get() : VlsConfig.ATTACK_DAMAGE.get();
            float power = isNuclear() ? VlsConfig.NUCLEAR_EXPLOSION_POWER.get().floatValue() : isInterceptor() ? 2.5f : 6f;
            float vehicleDamage = (float)(damage * VlsConfig.SBW_VEHICLE_DAMAGE_MULTIPLIER.get());
            if (target != null && target.isAlive()) {
                if (!SbwDamageCompat.hurtVehicle(target, this, getOwner(), vehicleDamage, false))
                    target.hurt(damageSources().explosion(this, getOwner()), (float)damage);
            }
            SbwDamageCompat.hurtVehiclesInRadius(level(), this, target, power, vehicleDamage * 0.75f);
            level().explode(this, getX(), getY(), getZ(), power, false, Level.ExplosionInteraction.TNT);
            discard();
        }
    }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        life = tag.getInt("Life"); entityData.set(MISSILE_TYPE, tag.contains("MissileType") ? tag.getInt("MissileType") : tag.getBoolean("Interceptor") ? 1 : 0);
        targetUuid = tag.hasUUID("Target") ? tag.getUUID("Target") : null;
        targetPoint = new Vec3(tag.getDouble("TX"), tag.getDouble("TY"), tag.getDouble("TZ"));
    }
    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Life", life); tag.putInt("MissileType", getMissileType()); if (targetUuid != null) tag.putUUID("Target", targetUuid);
        tag.putDouble("TX", targetPoint.x); tag.putDouble("TY", targetPoint.y); tag.putDouble("TZ", targetPoint.z);
    }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
