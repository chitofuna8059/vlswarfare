package jp.codex.vlswarfare.item;

import jp.codex.vlswarfare.VlsConfig;
import jp.codex.vlswarfare.blockentity.ControlConsoleBlockEntity;
import jp.codex.vlswarfare.blockentity.RadarBlockEntity;
import jp.codex.vlswarfare.blockentity.VlsLauncherBlockEntity;
import jp.codex.vlswarfare.block.VlsLauncherBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public final class DataLinkerItem extends Item {
    private static final String POS = "ControlPos", DIMENSION = "ControlDimension";
    public DataLinkerItem(Properties properties) { super(properties.stacksTo(1)); }

    @Override public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(context.getPlayer() instanceof ServerPlayer player)) return InteractionResult.PASS;
        BlockPos clicked = context.getClickedPos();
        CompoundTag tag = context.getItemInHand().getOrCreateTag();
        if (level.getBlockEntity(clicked) instanceof ControlConsoleBlockEntity) {
            tag.putLong(POS, clicked.asLong()); tag.putString(DIMENSION, level.dimension().location().toString());
            player.displayClientMessage(Component.translatable("message.vlswarfare.linker_selected", clicked.toShortString()), true);
            return InteractionResult.CONSUME;
        }
        if (!tag.contains(POS) || !level.dimension().location().toString().equals(tag.getString(DIMENSION))) {
            player.displayClientMessage(Component.translatable("message.vlswarfare.linker_no_control"), true); return InteractionResult.FAIL;
        }
        BlockPos controlPos = BlockPos.of(tag.getLong(POS));
        if (clicked.distSqr(controlPos) > Math.pow(VlsConfig.LINK_RANGE.get(), 2) || !(level.getBlockEntity(controlPos) instanceof ControlConsoleBlockEntity control)) {
            player.displayClientMessage(Component.translatable("message.vlswarfare.linker_out_of_range"), true); return InteractionResult.FAIL;
        }
        if (level.getBlockEntity(clicked) instanceof RadarBlockEntity radar) {
            BlockPos old = radar.getControlPos();
            if (controlPos.equals(old)) { radar.setControlPos(null); control.unlinkRadar(clicked); player.displayClientMessage(Component.translatable("message.vlswarfare.unlinked_radar"), true); }
            else {
                unlinkOldRadar(level, old, clicked);
                control.getRadarPos().filter(p -> !p.equals(clicked)).ifPresent(p -> { if (level.getBlockEntity(p) instanceof RadarBlockEntity previous && controlPos.equals(previous.getControlPos())) previous.setControlPos(null); });
                radar.setControlPos(controlPos); control.linkRadar(clicked);
                player.displayClientMessage(Component.translatable("message.vlswarfare.linked_radar"), true);
            }
            return InteractionResult.CONSUME;
        }
        BlockPos vlsPos = level.getBlockState(clicked).getBlock() instanceof VlsLauncherBlock ?
                clicked.offset(-(level.getBlockState(clicked).getValue(VlsLauncherBlock.PART) % 4), 0, -(level.getBlockState(clicked).getValue(VlsLauncherBlock.PART) / 4)) : clicked;
        if (level.getBlockEntity(vlsPos) instanceof VlsLauncherBlockEntity vls) {
            BlockPos old = vls.getControlPos();
            if (controlPos.equals(old)) { vls.setControlPos(null); control.unlinkLauncher(vlsPos); player.displayClientMessage(Component.translatable("message.vlswarfare.unlinked_vls"), true); }
            else { unlinkOldVls(level, old, vlsPos); vls.setControlPos(controlPos); control.linkLauncher(vlsPos); player.displayClientMessage(Component.translatable("message.vlswarfare.linked_vls"), true); }
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }
    private static void unlinkOldRadar(Level level, BlockPos old, BlockPos radar) { if (old != null && level.getBlockEntity(old) instanceof ControlConsoleBlockEntity c) c.unlinkRadar(radar); }
    private static void unlinkOldVls(Level level, BlockPos old, BlockPos vls) { if (old != null && level.getBlockEntity(old) instanceof ControlConsoleBlockEntity c) c.unlinkLauncher(vls); }
}
