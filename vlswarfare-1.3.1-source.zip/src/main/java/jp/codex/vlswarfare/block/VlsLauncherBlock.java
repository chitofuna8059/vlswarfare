package jp.codex.vlswarfare.block;

import jp.codex.vlswarfare.ModContent;
import jp.codex.vlswarfare.blockentity.VlsLauncherBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;
import java.util.List;

public final class VlsLauncherBlock extends BaseEntityBlock {
    public static final IntegerProperty PART = IntegerProperty.create("part", 0, 15);
    private static final ThreadLocal<Boolean> REMOVING = ThreadLocal.withInitial(() -> false);

    public VlsLauncherBlock() {
        super(BlockBehaviour.Properties.of().strength(8f, 20f).requiresCorrectToolForDrops());
        registerDefaultState(stateDefinition.any().setValue(PART, 0));
    }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) { builder.add(PART); }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return state.getValue(PART) == 0 ? new VlsLauncherBlockEntity(pos, state) : null; }

    @Override public @Nullable BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockPos origin = context.getClickedPos();
        for (int z = 0; z < 4; z++) for (int x = 0; x < 4; x++) {
            BlockPos p = origin.offset(x, 0, z);
            if (!context.getLevel().getBlockState(p).canBeReplaced(context)) return null;
        }
        return defaultBlockState();
    }

    @Override public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.isClientSide) return;
        for (int z = 0; z < 4; z++) for (int x = 0; x < 4; x++) {
            int part = z * 4 + x;
            if (part != 0) level.setBlock(pos.offset(x, 0, z), defaultBlockState().setValue(PART, part), 3);
        }
    }

    private static BlockPos controllerPos(BlockPos pos, BlockState state) {
        int part = state.getValue(PART);
        return pos.offset(-(part % 4), 0, -(part / 4));
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockPos controller = controllerPos(pos, state);
        if (!(level.getBlockEntity(controller) instanceof VlsLauncherBlockEntity vls)) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (held.is(ModContent.ATTACK_MISSILE.get()) || held.is(ModContent.INTERCEPTOR_MISSILE.get()) || held.is(ModContent.NUCLEAR_MISSILE.get())) {
            if (!level.isClientSide && vls.load(held.copyWithCount(1))) {
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (player.isShiftKeyDown() && !level.isClientSide && player instanceof ServerPlayer sp) {
            ItemStack removed = vls.unloadLast();
            if (!removed.isEmpty() && !sp.getInventory().add(removed)) sp.drop(removed, false);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && !player.getAbilities().instabuild && !REMOVING.get()) popResource(level, pos, new ItemStack(ModContent.VLS_ITEM.get()));
        super.playerWillDestroy(level, pos, state, player);
    }

    @Override public List<ItemStack> getDrops(BlockState state, LootParams.Builder params) { return List.of(); }

    @Override public void onRemove(BlockState state, Level level, BlockPos pos, BlockState next, boolean moving) {
        if (!state.is(next.getBlock()) && !REMOVING.get()) {
            BlockPos origin = controllerPos(pos, state);
            REMOVING.set(true);
            try {
                for (int z = 0; z < 4; z++) for (int x = 0; x < 4; x++) {
                    BlockPos p = origin.offset(x, 0, z);
                    if (level.getBlockState(p).is(this)) level.destroyBlock(p, false);
                }
            } finally { REMOVING.set(false); }
        }
        super.onRemove(state, level, pos, next, moving);
    }
}
