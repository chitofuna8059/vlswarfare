package jp.codex.vlswarfare.block;

import jp.codex.vlswarfare.blockentity.RadarBlockEntity;
import jp.codex.vlswarfare.network.NetworkHandler;
import jp.codex.vlswarfare.network.packet.OpenRadarPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public final class RadarBlock extends BaseEntityBlock {
    public RadarBlock() { super(BlockBehaviour.Properties.of().strength(6f, 15f).requiresCorrectToolForDrops()); }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new RadarBlockEntity(pos, state); }
    @Override public InteractionResult use(BlockState s, Level l, BlockPos p, Player player, InteractionHand h, BlockHitResult hit) {
        if (player.getItemInHand(h).is(jp.codex.vlswarfare.ModContent.DATA_LINKER.get())) return InteractionResult.PASS;
        if (!l.isClientSide && player instanceof ServerPlayer sp) NetworkHandler.send(sp, new OpenRadarPacket(p));
        return InteractionResult.sidedSuccess(l.isClientSide);
    }
}
