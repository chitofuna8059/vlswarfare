package jp.codex.vlswarfare;

import jp.codex.vlswarfare.network.NetworkHandler;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(VlsWarfare.MOD_ID)
public final class VlsWarfare {
    public static final String MOD_ID = "vlswarfare";

    public VlsWarfare() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModContent.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, VlsConfig.SPEC);
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(ServerEvents.class);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
