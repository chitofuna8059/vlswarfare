package jp.codex.vlswarfare.network.packet;

import jp.codex.vlswarfare.blockentity.ControlConsoleBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public record ControlActionPacket(BlockPos controlPos, int action, double x, double y, double z) {
    public static final int ATTACK = 0, INTERCEPT = 1, COORDINATE_ATTACK = 2, NUCLEAR = 3, NUCLEAR_COORDINATE = 4;
    public static void encode(ControlActionPacket p, FriendlyByteBuf b) { b.writeBlockPos(p.controlPos); b.writeVarInt(p.action); b.writeDouble(p.x); b.writeDouble(p.y); b.writeDouble(p.z); }
    public static ControlActionPacket decode(FriendlyByteBuf b) { return new ControlActionPacket(b.readBlockPos(),b.readVarInt(),b.readDouble(),b.readDouble(),b.readDouble()); }
    public static void handle(ControlActionPacket p, Supplier<NetworkEvent.Context> supplier) {
        ServerPlayer player=supplier.get().getSender(); if(player==null || player.distanceToSqr(p.controlPos.getCenter())>64*64 || !(player.level().getBlockEntity(p.controlPos) instanceof ControlConsoleBlockEntity control)) return;
        if (p.action == COORDINATE_ATTACK || p.action == NUCLEAR_COORDINATE) control.setCoordinateTarget(new Vec3(p.x,p.y,p.z));
        int missileType = p.action == INTERCEPT ? 1 : (p.action == NUCLEAR || p.action == NUCLEAR_COORDINATE) ? 2 : 0;
        boolean ok=control.launch(missileType);
        player.displayClientMessage(Component.translatable(ok?"message.vlswarfare.launched": control.getTargetName().equals("なし")?"message.vlswarfare.no_target":"message.vlswarfare.no_missile"),true);
    }
}
