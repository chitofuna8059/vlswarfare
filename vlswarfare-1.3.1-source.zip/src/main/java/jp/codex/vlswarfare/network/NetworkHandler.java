package jp.codex.vlswarfare.network;

import jp.codex.vlswarfare.VlsWarfare;
import jp.codex.vlswarfare.network.packet.*;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class NetworkHandler {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(VlsWarfare.id("main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(OpenRadarPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT).encoder(OpenRadarPacket::encode).decoder(OpenRadarPacket::decode).consumerMainThread(OpenRadarPacket::handle).add();
        CHANNEL.messageBuilder(OpenControlPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT).encoder(OpenControlPacket::encode).decoder(OpenControlPacket::decode).consumerMainThread(OpenControlPacket::handle).add();
        CHANNEL.messageBuilder(RadarScanRequestPacket.class, id++, NetworkDirection.PLAY_TO_SERVER).encoder(RadarScanRequestPacket::encode).decoder(RadarScanRequestPacket::decode).consumerMainThread(RadarScanRequestPacket::handle).add();
        CHANNEL.messageBuilder(RadarContactsPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT).encoder(RadarContactsPacket::encode).decoder(RadarContactsPacket::decode).consumerMainThread(RadarContactsPacket::handle).add();
        CHANNEL.messageBuilder(SelectTargetPacket.class, id++, NetworkDirection.PLAY_TO_SERVER).encoder(SelectTargetPacket::encode).decoder(SelectTargetPacket::decode).consumerMainThread(SelectTargetPacket::handle).add();
        CHANNEL.messageBuilder(ControlActionPacket.class, id, NetworkDirection.PLAY_TO_SERVER).encoder(ControlActionPacket::encode).decoder(ControlActionPacket::decode).consumerMainThread(ControlActionPacket::handle).add();
    }
    public static void send(ServerPlayer player, Object packet) { CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet); }
    public static void sendToServer(Object packet) { CHANNEL.sendToServer(packet); }
    private NetworkHandler() {}
}
