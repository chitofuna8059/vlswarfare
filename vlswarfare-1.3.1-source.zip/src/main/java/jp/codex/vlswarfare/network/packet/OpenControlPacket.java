package jp.codex.vlswarfare.network.packet;

import jp.codex.vlswarfare.client.ClientScreens;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.Optional;
import java.util.function.Supplier;

public record OpenControlPacket(BlockPos pos, Optional<BlockPos> radar, int launchers, String target) {
    public static void encode(OpenControlPacket p, FriendlyByteBuf b) { b.writeBlockPos(p.pos); b.writeBoolean(p.radar.isPresent()); p.radar.ifPresent(b::writeBlockPos); b.writeVarInt(p.launchers); b.writeUtf(p.target); }
    public static OpenControlPacket decode(FriendlyByteBuf b) { BlockPos p=b.readBlockPos(); Optional<BlockPos> r=b.readBoolean()?Optional.of(b.readBlockPos()):Optional.empty(); return new OpenControlPacket(p,r,b.readVarInt(),b.readUtf()); }
    public static void handle(OpenControlPacket p, Supplier<NetworkEvent.Context> c) { ClientScreens.openControl(p.pos,p.radar,p.launchers,p.target); c.get().setPacketHandled(true); }
}
