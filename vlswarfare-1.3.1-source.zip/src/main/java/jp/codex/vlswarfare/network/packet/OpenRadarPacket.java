package jp.codex.vlswarfare.network.packet;

import jp.codex.vlswarfare.client.ClientScreens;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public record OpenRadarPacket(BlockPos pos) {
    public static void encode(OpenRadarPacket p, FriendlyByteBuf b) { b.writeBlockPos(p.pos); }
    public static OpenRadarPacket decode(FriendlyByteBuf b) { return new OpenRadarPacket(b.readBlockPos()); }
    public static void handle(OpenRadarPacket p, Supplier<NetworkEvent.Context> c) { ClientScreens.openRadar(p.pos); c.get().setPacketHandled(true); }
}
