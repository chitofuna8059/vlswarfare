package jp.codex.vlswarfare.network.packet;

import jp.codex.vlswarfare.VlsConfig;
import jp.codex.vlswarfare.blockentity.RadarBlockEntity;
import jp.codex.vlswarfare.entity.GuidedMissileEntity;
import jp.codex.vlswarfare.network.NetworkHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public record RadarScanRequestPacket(BlockPos radarPos) {
    public static void encode(RadarScanRequestPacket p, FriendlyByteBuf b) { b.writeBlockPos(p.radarPos); }
    public static RadarScanRequestPacket decode(FriendlyByteBuf b) { return new RadarScanRequestPacket(b.readBlockPos()); }
    public static void handle(RadarScanRequestPacket p, Supplier<NetworkEvent.Context> supplier) {
        ServerPlayer player = supplier.get().getSender();
        if (player == null || !(player.level().getBlockEntity(p.radarPos) instanceof RadarBlockEntity) || player.distanceToSqr(p.radarPos.getCenter()) > 64 * 64) return;
        double range = VlsConfig.RADAR_RANGE.get();
        AABB box = new AABB(p.radarPos).inflate(range);
        List<RadarContactsPacket.Contact> contacts = new ArrayList<>();
        for (Entity e : player.level().getEntities(player, box, RadarScanRequestPacket::detectable)) {
            if (contacts.size() >= 512) break;
            String type = e instanceof GuidedMissileEntity || e.getClass().getSimpleName().toLowerCase().contains("missile") ? "MISSILE" :
                    (e.onGround() ? "VEHICLE" : "AIRCRAFT");
            contacts.add(new RadarContactsPacket.Contact(e.getId(), e.getDisplayName().getString(), type, e.getX(), e.getY(), e.getZ()));
        }
        NetworkHandler.send(player, new RadarContactsPacket(p.radarPos, range, contacts));
    }
    private static boolean detectable(Entity e) {
        String namespace = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getNamespace();
        String name = e.getClass().getName().toLowerCase();
        return e instanceof GuidedMissileEntity || namespace.equals("superbwarfare") && (name.contains("vehicle") || name.contains("aircraft") || name.contains("helicopter") || name.contains("missile"));
    }
}
