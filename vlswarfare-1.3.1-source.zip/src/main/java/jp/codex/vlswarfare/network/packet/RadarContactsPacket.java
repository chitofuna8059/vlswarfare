package jp.codex.vlswarfare.network.packet;

import jp.codex.vlswarfare.client.ClientScreens;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public record RadarContactsPacket(BlockPos radarPos, double range, List<Contact> contacts) {
    public record Contact(int id, String name, String type, double x, double y, double z) {}
    public static void encode(RadarContactsPacket p, FriendlyByteBuf b) {
        b.writeBlockPos(p.radarPos); b.writeDouble(p.range); b.writeVarInt(p.contacts.size());
        for (Contact c : p.contacts) { b.writeVarInt(c.id); b.writeUtf(c.name); b.writeUtf(c.type); b.writeDouble(c.x); b.writeDouble(c.y); b.writeDouble(c.z); }
    }
    public static RadarContactsPacket decode(FriendlyByteBuf b) {
        BlockPos p=b.readBlockPos(); double r=b.readDouble(); int n=b.readVarInt(); List<Contact> list=new ArrayList<>(n);
        for(int i=0;i<n;i++) list.add(new Contact(b.readVarInt(),b.readUtf(),b.readUtf(),b.readDouble(),b.readDouble(),b.readDouble()));
        return new RadarContactsPacket(p,r,list);
    }
    public static void handle(RadarContactsPacket p, Supplier<NetworkEvent.Context> c) { ClientScreens.updateContacts(p); c.get().setPacketHandled(true); }
}
