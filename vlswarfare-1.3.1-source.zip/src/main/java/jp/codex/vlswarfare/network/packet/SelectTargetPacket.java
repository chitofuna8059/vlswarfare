package jp.codex.vlswarfare.network.packet;

import jp.codex.vlswarfare.blockentity.ControlConsoleBlockEntity;
import jp.codex.vlswarfare.blockentity.RadarBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public record SelectTargetPacket(BlockPos radarPos, int entityId) {
    public static void encode(SelectTargetPacket p, FriendlyByteBuf b) { b.writeBlockPos(p.radarPos); b.writeVarInt(p.entityId); }
    public static SelectTargetPacket decode(FriendlyByteBuf b) { return new SelectTargetPacket(b.readBlockPos(), b.readVarInt()); }
    public static void handle(SelectTargetPacket p, Supplier<NetworkEvent.Context> supplier) {
        ServerPlayer player = supplier.get().getSender(); if (player == null) return;
        Entity target = player.level().getEntity(p.entityId); if (target == null) return;
        if (!(player.level().getBlockEntity(p.radarPos) instanceof RadarBlockEntity radar) || radar.getControlPos() == null) return;
        player.getPersistentData().putUUID("vlswarfare:target", target.getUUID());
        player.getPersistentData().putString("vlswarfare:target_name", target.getDisplayName().getString());
        if (player.level().getBlockEntity(radar.getControlPos()) instanceof ControlConsoleBlockEntity control) control.setEntityTarget(target);
    }
}
