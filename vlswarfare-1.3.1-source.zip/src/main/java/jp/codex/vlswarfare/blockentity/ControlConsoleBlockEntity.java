package jp.codex.vlswarfare.blockentity;

import jp.codex.vlswarfare.ModContent;
import jp.codex.vlswarfare.ServerEvents;
import jp.codex.vlswarfare.entity.GuidedMissileEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class ControlConsoleBlockEntity extends BlockEntity {
    private BlockPos radarPos;
    private final List<BlockPos> launchers = new ArrayList<>();
    private UUID targetUuid;
    private String targetName = "なし";
    private Vec3 coordinateTarget;

    public ControlConsoleBlockEntity(BlockPos pos, BlockState state) { super(ModContent.CONTROL_BE.get(), pos, state); }
    @Override public void onLoad() { super.onLoad(); ServerEvents.loaded(this); }
    @Override public void setRemoved() {
        if (level != null && !level.isClientSide) {
            if (radarPos != null && level.getBlockEntity(radarPos) instanceof RadarBlockEntity radar && worldPosition.equals(radar.getControlPos())) radar.setControlPos(null);
            for (BlockPos pos : launchers) if (level.getBlockEntity(pos) instanceof VlsLauncherBlockEntity vls && worldPosition.equals(vls.getControlPos())) vls.setControlPos(null);
        }
        ServerEvents.removed(this); super.setRemoved();
    }

    public void linkRadar(BlockPos pos) { radarPos = pos.immutable(); setChanged(); }
    public void unlinkRadar(BlockPos pos) { if (pos.equals(radarPos)) { radarPos = null; setChanged(); } }
    public void linkLauncher(BlockPos pos) { if (!launchers.contains(pos)) { launchers.add(pos.immutable()); setChanged(); } }
    public void unlinkLauncher(BlockPos pos) { if (launchers.remove(pos)) setChanged(); }

    public boolean setEntityTarget(Entity target) {
        if (target == null || target.isRemoved()) return false;
        targetUuid = target.getUUID(); targetName = target.getDisplayName().getString(); coordinateTarget = null; setChanged(); return true;
    }
    public void setCoordinateTarget(Vec3 target) {
        coordinateTarget = target; targetUuid = null;
        targetName = String.format("X %.0f / Y %.0f / Z %.0f", target.x, target.y, target.z); setChanged();
    }
    public boolean launch(int missileType) {
        if (!(level instanceof ServerLevel server)) return false;
        Entity target = targetUuid == null ? null : server.getEntity(targetUuid);
        Vec3 point = target != null ? target.getBoundingBox().getCenter() : coordinateTarget;
        if (point == null) return false;
        for (BlockPos pos : launchers) {
            if (server.getBlockEntity(pos) instanceof VlsLauncherBlockEntity vls && worldPosition.equals(vls.getControlPos()) && vls.consume(missileType)) {
                GuidedMissileEntity missile = new GuidedMissileEntity(ModContent.GUIDED_MISSILE.get(), server);
                missile.setPos(pos.getX() + .5, pos.getY() + 1.2, pos.getZ() + .5);
                missile.configure(missileType, target, point);
                server.addFreshEntity(missile);
                return true;
            }
        }
        return false;
    }
    public Optional<BlockPos> getRadarPos() { return Optional.ofNullable(radarPos); }
    public String getTargetName() { return targetName; }
    public List<BlockPos> getLaunchers() { return List.copyOf(launchers); }

    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (radarPos != null) tag.putLong("ManualRadar", radarPos.asLong());
        if (targetUuid != null) tag.putUUID("Target", targetUuid);
        tag.putString("TargetName", targetName);
        if (coordinateTarget != null) { tag.putDouble("TargetX", coordinateTarget.x); tag.putDouble("TargetY", coordinateTarget.y); tag.putDouble("TargetZ", coordinateTarget.z); }
        tag.putLongArray("ManualLaunchers", launchers.stream().mapToLong(BlockPos::asLong).toArray());
    }
    @Override public void load(CompoundTag tag) {
        super.load(tag); radarPos = tag.contains("ManualRadar") ? BlockPos.of(tag.getLong("ManualRadar")) : null;
        targetUuid = tag.hasUUID("Target") ? tag.getUUID("Target") : null; targetName = tag.getString("TargetName");
        coordinateTarget = tag.contains("TargetX") ? new Vec3(tag.getDouble("TargetX"), tag.getDouble("TargetY"), tag.getDouble("TargetZ")) : null;
        launchers.clear(); for (long p : tag.getLongArray("ManualLaunchers")) launchers.add(BlockPos.of(p));
    }
}
