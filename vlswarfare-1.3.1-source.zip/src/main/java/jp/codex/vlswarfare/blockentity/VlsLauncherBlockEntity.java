package jp.codex.vlswarfare.blockentity;

import jp.codex.vlswarfare.ModContent;
import jp.codex.vlswarfare.ServerEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class VlsLauncherBlockEntity extends BlockEntity {
    public static final int CAPACITY = 16;
    private final ItemStackHandler inventory = new ItemStackHandler(CAPACITY) {
        @Override protected void onContentsChanged(int slot) { setChanged(); }
        @Override public boolean isItemValid(int slot, ItemStack stack) {
            return stack.is(ModContent.ATTACK_MISSILE.get()) || stack.is(ModContent.INTERCEPTOR_MISSILE.get()) || stack.is(ModContent.NUCLEAR_MISSILE.get());
        }
        @Override public int getSlotLimit(int slot) { return 1; }
    };
    private LazyOptional<ItemStackHandler> capability = LazyOptional.of(() -> inventory);
    private BlockPos controlPos;

    public VlsLauncherBlockEntity(BlockPos pos, BlockState state) { super(ModContent.VLS_BE.get(), pos, state); }
    @Override public void onLoad() { super.onLoad(); ServerEvents.loaded(this); }
    @Override public void setRemoved() {
        if (level != null && !level.isClientSide && controlPos != null && level.getBlockEntity(controlPos) instanceof ControlConsoleBlockEntity c) c.unlinkLauncher(worldPosition);
        ServerEvents.removed(this); super.setRemoved();
    }

    public boolean load(ItemStack missile) {
        for (int i = 0; i < CAPACITY; i++) if (inventory.getStackInSlot(i).isEmpty()) {
            inventory.setStackInSlot(i, missile); return true;
        }
        return false;
    }
    public boolean has(int missileType) {
        for (int i = 0; i < CAPACITY; i++) if (matches(inventory.getStackInSlot(i), missileType)) return true;
        return false;
    }
    public boolean consume(int missileType) {
        for (int i = 0; i < CAPACITY; i++) if (matches(inventory.getStackInSlot(i), missileType)) {
            inventory.extractItem(i, 1, false); return true;
        }
        return false;
    }
    private boolean matches(ItemStack stack, int missileType) {
        return missileType == 1 ? stack.is(ModContent.INTERCEPTOR_MISSILE.get()) : missileType == 2 ? stack.is(ModContent.NUCLEAR_MISSILE.get()) : stack.is(ModContent.ATTACK_MISSILE.get());
    }
    public ItemStack unloadLast() {
        for (int i = CAPACITY - 1; i >= 0; i--) if (!inventory.getStackInSlot(i).isEmpty()) return inventory.extractItem(i, 1, false);
        return ItemStack.EMPTY;
    }
    public int count(int missileType) {
        int n = 0; for (int i = 0; i < CAPACITY; i++) if (matches(inventory.getStackInSlot(i), missileType)) n++; return n;
    }
    public BlockPos getControlPos() { return controlPos; }
    public void setControlPos(BlockPos pos) { controlPos = pos == null ? null : pos.immutable(); setChanged(); }
    @Override protected void saveAdditional(CompoundTag tag) { super.saveAdditional(tag); tag.put("Inventory", inventory.serializeNBT()); if (controlPos != null) tag.putLong("ManualControl", controlPos.asLong()); }
    @Override public void load(CompoundTag tag) { super.load(tag); inventory.deserializeNBT(tag.getCompound("Inventory")); controlPos = tag.contains("ManualControl") ? BlockPos.of(tag.getLong("ManualControl")) : null; }
    @Override public void invalidateCaps() { super.invalidateCaps(); capability.invalidate(); }
    @Override public void reviveCaps() { super.reviveCaps(); capability = LazyOptional.of(() -> inventory); }
    @Override public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable net.minecraft.core.Direction side) {
        return cap == ForgeCapabilities.ITEM_HANDLER ? capability.cast() : super.getCapability(cap, side);
    }
}
