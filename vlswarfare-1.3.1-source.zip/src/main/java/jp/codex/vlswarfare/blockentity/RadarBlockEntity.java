package jp.codex.vlswarfare.blockentity;

import jp.codex.vlswarfare.ModContent;
import jp.codex.vlswarfare.ServerEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public final class RadarBlockEntity extends BlockEntity {
    private BlockPos controlPos;
    public RadarBlockEntity(BlockPos pos, BlockState state) { super(ModContent.RADAR_BE.get(), pos, state); }
    @Override public void onLoad() { super.onLoad(); ServerEvents.loaded(this); }
    @Override public void setRemoved() {
        if (level != null && !level.isClientSide && controlPos != null && level.getBlockEntity(controlPos) instanceof ControlConsoleBlockEntity c) c.unlinkRadar(worldPosition);
        ServerEvents.removed(this); super.setRemoved();
    }
    public BlockPos getControlPos() { return controlPos; }
    public void setControlPos(BlockPos pos) { controlPos = pos == null ? null : pos.immutable(); setChanged(); }
    @Override protected void saveAdditional(CompoundTag tag) { super.saveAdditional(tag); if (controlPos != null) tag.putLong("ManualControl", controlPos.asLong()); }
    @Override public void load(CompoundTag tag) { super.load(tag); controlPos = tag.contains("ManualControl") ? BlockPos.of(tag.getLong("ManualControl")) : null; }
}
