package jp.codex.vlswarfare;

import jp.codex.vlswarfare.blockentity.ControlConsoleBlockEntity;
import jp.codex.vlswarfare.blockentity.RadarBlockEntity;
import jp.codex.vlswarfare.blockentity.VlsLauncherBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class ServerEvents {
    private static final Map<ResourceKey<Level>, Set<BlockPos>> RADARS = new ConcurrentHashMap<>();
    private static final Map<ResourceKey<Level>, Set<BlockPos>> LAUNCHERS = new ConcurrentHashMap<>();
    private static final Map<ResourceKey<Level>, Set<BlockPos>> CONTROLS = new ConcurrentHashMap<>();

    public static void loaded(BlockEntity be) {
        if (be.getLevel() == null || be.getLevel().isClientSide) return;
        Map<ResourceKey<Level>, Set<BlockPos>> map = be instanceof RadarBlockEntity ? RADARS : be instanceof VlsLauncherBlockEntity ? LAUNCHERS : be instanceof ControlConsoleBlockEntity ? CONTROLS : null;
        if (map != null) map.computeIfAbsent(be.getLevel().dimension(), k -> ConcurrentHashMap.newKeySet()).add(be.getBlockPos().immutable());
    }
    public static void removed(BlockEntity be) {
        if (be.getLevel() == null || be.getLevel().isClientSide) return;
        Map<ResourceKey<Level>, Set<BlockPos>> map = be instanceof RadarBlockEntity ? RADARS : be instanceof VlsLauncherBlockEntity ? LAUNCHERS : be instanceof ControlConsoleBlockEntity ? CONTROLS : null;
        if (map != null) map.getOrDefault(be.getLevel().dimension(), Set.of()).remove(be.getBlockPos());
    }
    public static Set<BlockPos> radars(Level level) { return RADARS.getOrDefault(level.dimension(), Set.of()); }
    public static Set<BlockPos> launchers(Level level) { return LAUNCHERS.getOrDefault(level.dimension(), Set.of()); }
    public static Set<BlockPos> controls(Level level) { return CONTROLS.getOrDefault(level.dimension(), Set.of()); }

    private ServerEvents() {}
}
