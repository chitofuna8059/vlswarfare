package jp.codex.vlswarfare.client;

import jp.codex.vlswarfare.ModContent;
import jp.codex.vlswarfare.client.render.GuidedMissileRenderer;
import net.minecraftforge.client.event.EntityRenderersEvent;
import jp.codex.vlswarfare.VlsWarfare;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = VlsWarfare.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers event) { event.registerEntityRenderer(ModContent.GUIDED_MISSILE.get(), GuidedMissileRenderer::new); }
    @SubscribeEvent public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) { event.registerLayerDefinition(GuidedMissileRenderer.LAYER, GuidedMissileRenderer::createBodyLayer); }
    private ClientSetup() {}
}
