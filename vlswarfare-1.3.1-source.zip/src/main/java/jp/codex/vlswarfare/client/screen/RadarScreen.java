package jp.codex.vlswarfare.client.screen;

import jp.codex.vlswarfare.network.NetworkHandler;
import jp.codex.vlswarfare.network.packet.RadarContactsPacket;
import jp.codex.vlswarfare.network.packet.RadarScanRequestPacket;
import jp.codex.vlswarfare.network.packet.SelectTargetPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import java.util.List;

public final class RadarScreen extends Screen {
    private final BlockPos radarPos;
    private List<RadarContactsPacket.Contact> contacts=List.of();
    private double range=10000;
    private int selected=-1, ticks;
    public RadarScreen(BlockPos pos) { super(Component.literal("戦術レーダー / TACTICAL RADAR")); radarPos=pos; }
    @Override protected void init() { NetworkHandler.sendToServer(new RadarScanRequestPacket(radarPos)); }
    @Override public void tick() { if(++ticks%40==0) NetworkHandler.sendToServer(new RadarScanRequestPacket(radarPos)); }
    @Override public boolean isPauseScreen(){return false;}
    public BlockPos getRadarPos(){return radarPos;}
    public void setContacts(List<RadarContactsPacket.Contact> contacts,double range){this.contacts=contacts;this.range=range;}
    @Override public void render(GuiGraphics g,int mx,int my,float pt){
        renderBackground(g); int cx=width/2,cy=height/2,r=Math.min(width,height)/2-28;
        g.fill(cx-r-3,cy-r-3,cx+r+3,cy+r+3,0xDD071711); g.renderOutline(cx-r,cy-r,r*2,r*2,0xFF36E58C);
        for(int q=1;q<=4;q++){int rr=r*q/4;g.renderOutline(cx-rr,cy-rr,rr*2,rr*2,0x5536E58C);}
        g.hLine(cx-r,cx+r,cy,0x7736E58C);g.vLine(cx,cy-r,cy+r,0x7736E58C);
        for(int i=0;i<contacts.size();i++){
            var c=contacts.get(i); double dx=c.x()-(radarPos.getX()+.5),dz=c.z()-(radarPos.getZ()+.5);
            int px=cx+(int)Math.round(dx/range*r),py=cy+(int)Math.round(dz/range*r);
            if(Math.abs(px-cx)<=r&&Math.abs(py-cy)<=r){int color=c.type().equals("MISSILE")?0xFFFF453A:c.type().equals("AIRCRAFT")?0xFFFFD60A:0xFF64D2FF;g.fill(px-3,py-3,px+4,py+4,i==selected?0xFFFFFFFF:color);}
        }
        g.drawCenteredString(font,title,cx,8,0xFF7CFFB2);g.drawString(font,"範囲: "+(int)range+"m  捕捉: "+contacts.size(),12,12,0xFFA5FFD0);
        if(selected>=0&&selected<contacts.size()){var c=contacts.get(selected);g.drawCenteredString(font,"選択: "+c.name()+" ["+c.type()+"]",cx,height-18,0xFFFFFFFF);}
        super.render(g,mx,my,pt);
    }
    @Override public boolean mouseClicked(double mx,double my,int button){
        int cx=width/2,cy=height/2,r=Math.min(width,height)/2-28,best=-1;double bestD=100;
        for(int i=0;i<contacts.size();i++){var c=contacts.get(i);int px=cx+(int)((c.x()-radarPos.getX()-.5)/range*r),py=cy+(int)((c.z()-radarPos.getZ()-.5)/range*r);double d=(px-mx)*(px-mx)+(py-my)*(py-my);if(d<bestD){bestD=d;best=i;}}
        if(best>=0){selected=best;NetworkHandler.sendToServer(new SelectTargetPacket(radarPos,contacts.get(best).id()));return true;}return super.mouseClicked(mx,my,button);
    }
}
