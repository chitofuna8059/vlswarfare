package jp.codex.vlswarfare.client.screen;

import jp.codex.vlswarfare.network.NetworkHandler;
import jp.codex.vlswarfare.network.packet.ControlActionPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import java.util.Optional;

public final class ControlScreen extends Screen {
    private final BlockPos pos; private final Optional<BlockPos> radar; private final int launchers; private final String target;
    private EditBox x,y,z;
    public ControlScreen(BlockPos pos,Optional<BlockPos> radar,int launchers,String target){super(Component.literal("VLS 火器管制装置"));this.pos=pos;this.radar=radar;this.launchers=launchers;this.target=target;}
    @Override protected void init(){
        int cx=width/2;
        addRenderableWidget(Button.builder(Component.literal("攻撃ミサイル 発射"),b->send(ControlActionPacket.ATTACK,0,0,0)).bounds(cx-105,height/2-10,100,20).build());
        addRenderableWidget(Button.builder(Component.literal("迎撃ミサイル 発射"),b->send(ControlActionPacket.INTERCEPT,0,0,0)).bounds(cx+5,height/2-10,100,20).build());
        addRenderableWidget(Button.builder(Component.literal("核ミサイル 発射"),b->send(ControlActionPacket.NUCLEAR,0,0,0)).bounds(cx-50,height/2+14,100,20).build());
        x=coord(cx-105,height/2+55,"X",pos.getX());y=coord(cx-35,height/2+55,"Y",pos.getY());z=coord(cx+35,height/2+55,"Z",pos.getZ());
        addRenderableWidget(x);addRenderableWidget(y);addRenderableWidget(z);
        addRenderableWidget(Button.builder(Component.literal("通常弾 座標攻撃"),b->{try{send(ControlActionPacket.COORDINATE_ATTACK,Double.parseDouble(x.getValue()),Double.parseDouble(y.getValue()),Double.parseDouble(z.getValue()));}catch(NumberFormatException ignored){}}).bounds(cx-105,height/2+82,100,20).build());
        addRenderableWidget(Button.builder(Component.literal("核弾頭 座標攻撃"),b->{try{send(ControlActionPacket.NUCLEAR_COORDINATE,Double.parseDouble(x.getValue()),Double.parseDouble(y.getValue()),Double.parseDouble(z.getValue()));}catch(NumberFormatException ignored){}}).bounds(cx+5,height/2+82,100,20).build());
    }
    private EditBox coord(int px,int py,String hint,int value){EditBox e=new EditBox(font,px,py,65,20,Component.literal(hint));e.setValue(Integer.toString(value));e.setHint(Component.literal(hint));return e;}
    private void send(int action,double a,double b,double c){NetworkHandler.sendToServer(new ControlActionPacket(pos,action,a,b,c));}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void render(GuiGraphics g,int mx,int my,float pt){renderBackground(g);int cx=width/2;g.fill(cx-125,height/2-90,cx+125,height/2+115,0xDD101820);g.renderOutline(cx-125,height/2-90,250,205,0xFF5AB4D6);g.drawCenteredString(font,title,cx,height/2-78,0xFFFFFFFF);g.drawCenteredString(font,"レーダー: "+(radar.isPresent()?"LINK":"OFFLINE")+" / VLS: "+launchers+"基",cx,height/2-58,radar.isPresent()?0xFF72FF9B:0xFFFF665E);g.drawCenteredString(font,"選択目標: "+target,cx,height/2-40,0xFFFFD76A);g.drawString(font,"地上座標指定 X / Y / Z",cx-105,height/2+42,0xFFB9C7D5);super.render(g,mx,my,pt);}
}
