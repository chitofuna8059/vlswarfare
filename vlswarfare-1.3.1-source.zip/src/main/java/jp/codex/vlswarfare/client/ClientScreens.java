package jp.codex.vlswarfare.client;

import jp.codex.vlswarfare.client.screen.ControlScreen;
import jp.codex.vlswarfare.client.screen.RadarScreen;
import jp.codex.vlswarfare.network.packet.RadarContactsPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import java.util.Optional;

public final class ClientScreens {
    public static void openRadar(BlockPos pos) { Minecraft.getInstance().setScreen(new RadarScreen(pos)); }
    public static void openControl(BlockPos pos, Optional<BlockPos> radar, int launchers, String target) { Minecraft.getInstance().setScreen(new ControlScreen(pos,radar,launchers,target)); }
    public static void updateContacts(RadarContactsPacket packet) {
        if(Minecraft.getInstance().screen instanceof RadarScreen screen && screen.getRadarPos().equals(packet.radarPos())) screen.setContacts(packet.contacts(),packet.range());
    }
    private ClientScreens() {}
}
