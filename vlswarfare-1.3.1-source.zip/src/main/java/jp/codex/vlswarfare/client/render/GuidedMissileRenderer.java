package jp.codex.vlswarfare.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import jp.codex.vlswarfare.VlsWarfare;
import jp.codex.vlswarfare.entity.GuidedMissileEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

public final class GuidedMissileRenderer extends EntityRenderer<GuidedMissileEntity> {
    public static final ModelLayerLocation LAYER=new ModelLayerLocation(VlsWarfare.id("guided_missile"),"main");
    private static final ResourceLocation ATTACK=VlsWarfare.id("textures/entity/attack_missile.png"), INTERCEPT=VlsWarfare.id("textures/entity/interceptor_missile.png"), NUCLEAR=VlsWarfare.id("textures/entity/nuclear_missile.png");
    private final MissileModel model;
    public GuidedMissileRenderer(EntityRendererProvider.Context c){super(c);model=new MissileModel(c.bakeLayer(LAYER));shadowRadius=.2f;}
    public static LayerDefinition createBodyLayer(){MeshDefinition mesh=new MeshDefinition();PartDefinition root=mesh.getRoot();root.addOrReplaceChild("missile",CubeListBuilder.create().texOffs(0,0).addBox(-2,-12,-2,4,20,4).texOffs(0,24).addBox(-1,-16,-1,2,4,2).texOffs(16,0).addBox(-7,4,-1,14,2,2).texOffs(16,4).addBox(-1,4,-7,2,2,14),PartPose.ZERO);return LayerDefinition.create(mesh,64,32);}
    @Override public void render(GuidedMissileEntity e,float yaw,float pt,PoseStack pose,MultiBufferSource buf,int light){pose.pushPose();pose.translate(0,.8,0);pose.scale(1.35f,1.35f,1.35f);pose.mulPose(Axis.YP.rotationDegrees(180-yaw));pose.mulPose(Axis.XP.rotationDegrees(e.getXRot()+90));pose.mulPose(Axis.XP.rotationDegrees(180));pose.mulPose(Axis.YP.rotationDegrees((e.tickCount+pt)*18));VertexConsumer vc=buf.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(e)));model.renderToBuffer(pose,vc,Math.max(light,LightTexture.pack(12,12)),net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY,1,1,1,1);pose.popPose();super.render(e,yaw,pt,pose,buf,light);}
    @Override public ResourceLocation getTextureLocation(GuidedMissileEntity e){return e.isNuclear()?NUCLEAR:e.isInterceptor()?INTERCEPT:ATTACK;}
    private static final class MissileModel extends EntityModel<GuidedMissileEntity>{private final ModelPart root;MissileModel(ModelPart root){this.root=root.getChild("missile");}@Override public void setupAnim(GuidedMissileEntity e,float a,float b,float c,float d,float f){}@Override public void renderToBuffer(PoseStack p,VertexConsumer v,int l,int o,float r,float g,float b,float a){root.render(p,v,l,o,r,g,b,a);}}
}
