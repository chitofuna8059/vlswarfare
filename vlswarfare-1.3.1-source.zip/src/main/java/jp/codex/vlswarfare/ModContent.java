package jp.codex.vlswarfare;

import jp.codex.vlswarfare.block.ControlConsoleBlock;
import jp.codex.vlswarfare.block.RadarBlock;
import jp.codex.vlswarfare.block.VlsLauncherBlock;
import jp.codex.vlswarfare.blockentity.ControlConsoleBlockEntity;
import jp.codex.vlswarfare.blockentity.RadarBlockEntity;
import jp.codex.vlswarfare.blockentity.VlsLauncherBlockEntity;
import jp.codex.vlswarfare.entity.GuidedMissileEntity;
import jp.codex.vlswarfare.item.DataLinkerItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.network.chat.Component;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModContent {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, VlsWarfare.MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, VlsWarfare.MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, VlsWarfare.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, VlsWarfare.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, VlsWarfare.MOD_ID);

    public static final RegistryObject<Block> VLS = BLOCKS.register("vls_launcher", VlsLauncherBlock::new);
    public static final RegistryObject<Block> CONTROL = BLOCKS.register("control_console", ControlConsoleBlock::new);
    public static final RegistryObject<Block> RADAR = BLOCKS.register("radar", RadarBlock::new);

    public static final RegistryObject<Item> ATTACK_MISSILE = ITEMS.register("attack_missile", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> INTERCEPTOR_MISSILE = ITEMS.register("interceptor_missile", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> NUCLEAR_MISSILE = ITEMS.register("nuclear_missile", () -> new Item(new Item.Properties().stacksTo(4).fireResistant()));
    public static final RegistryObject<Item> DATA_LINKER = ITEMS.register("data_linker", () -> new DataLinkerItem(new Item.Properties()));
    public static final RegistryObject<Item> VLS_ITEM = blockItem("vls_launcher", VLS);
    public static final RegistryObject<Item> CONTROL_ITEM = blockItem("control_console", CONTROL);
    public static final RegistryObject<Item> RADAR_ITEM = blockItem("radar", RADAR);

    public static final RegistryObject<EntityType<GuidedMissileEntity>> GUIDED_MISSILE = ENTITIES.register("guided_missile", () ->
            EntityType.Builder.<GuidedMissileEntity>of(GuidedMissileEntity::new, MobCategory.MISC)
                    .sized(0.35f, 1.8f).clientTrackingRange(256).updateInterval(1).fireImmune().build("guided_missile"));

    public static final RegistryObject<BlockEntityType<VlsLauncherBlockEntity>> VLS_BE = BLOCK_ENTITIES.register("vls_launcher", () ->
            BlockEntityType.Builder.of(VlsLauncherBlockEntity::new, VLS.get()).build(null));
    public static final RegistryObject<BlockEntityType<ControlConsoleBlockEntity>> CONTROL_BE = BLOCK_ENTITIES.register("control_console", () ->
            BlockEntityType.Builder.of(ControlConsoleBlockEntity::new, CONTROL.get()).build(null));
    public static final RegistryObject<BlockEntityType<RadarBlockEntity>> RADAR_BE = BLOCK_ENTITIES.register("radar", () ->
            BlockEntityType.Builder.of(RadarBlockEntity::new, RADAR.get()).build(null));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.vlswarfare")).icon(() -> RADAR_ITEM.get().getDefaultInstance())
            .displayItems((p, out) -> {
                out.accept(ATTACK_MISSILE.get()); out.accept(INTERCEPTOR_MISSILE.get()); out.accept(NUCLEAR_MISSILE.get()); out.accept(DATA_LINKER.get());
                out.accept(VLS_ITEM.get()); out.accept(CONTROL_ITEM.get()); out.accept(RADAR_ITEM.get());
            }).build());

    private static RegistryObject<Item> blockItem(String name, RegistryObject<Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus); ITEMS.register(bus); ENTITIES.register(bus); BLOCK_ENTITIES.register(bus); TABS.register(bus);
    }

    private ModContent() {}
}
