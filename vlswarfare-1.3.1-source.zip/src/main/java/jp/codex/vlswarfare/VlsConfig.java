package jp.codex.vlswarfare;

import net.minecraftforge.common.ForgeConfigSpec;

public final class VlsConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue MISSILE_SPEED;
    public static final ForgeConfigSpec.DoubleValue LAUNCH_SPEED;
    public static final ForgeConfigSpec.IntValue VERTICAL_LAUNCH_TICKS;
    public static final ForgeConfigSpec.IntValue ACCELERATION_TICKS;
    public static final ForgeConfigSpec.DoubleValue RADAR_RANGE;
    public static final ForgeConfigSpec.DoubleValue ATTACK_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue INTERCEPT_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue NUCLEAR_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue NUCLEAR_EXPLOSION_POWER;
    public static final ForgeConfigSpec.DoubleValue SBW_VEHICLE_DAMAGE_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue LINK_RANGE;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("missiles");
        MISSILE_SPEED = b.comment("Flight speed in blocks per second.").defineInRange("speedBlocksPerSecond", 200.0, 1.0, 2000.0);
        LAUNCH_SPEED = b.comment("Initial vertical ejection speed in blocks per second.").defineInRange("launchSpeedBlocksPerSecond", 8.0, 1.0, 80.0);
        VERTICAL_LAUNCH_TICKS = b.comment("Ticks spent rising vertically before turning toward the target.").defineInRange("verticalLaunchTicks", 16, 1, 100);
        ACCELERATION_TICKS = b.comment("Ticks used to accelerate from launch speed to cruise speed.").defineInRange("accelerationTicks", 24, 1, 200);
        ATTACK_DAMAGE = b.defineInRange("attackDamage", 160.0, 1.0, 10000.0);
        INTERCEPT_DAMAGE = b.defineInRange("interceptorDamage", 80.0, 1.0, 10000.0);
        NUCLEAR_DAMAGE = b.comment("Direct-hit damage of a nuclear missile.").defineInRange("nuclearDamage", 2000.0, 1.0, 100000.0);
        NUCLEAR_EXPLOSION_POWER = b.comment("Nuclear explosion radius/power. Large values can cause server lag.").defineInRange("nuclearExplosionPower", 24.0, 1.0, 64.0);
        SBW_VEHICLE_DAMAGE_MULTIPLIER = b.comment("Damage multiplier applied specifically to Superb Warfare vehicles after their armor system.").defineInRange("superbWarfareVehicleDamageMultiplier", 6.0, 0.1, 100.0);
        b.pop().push("radar");
        RADAR_RANGE = b.comment("Detection radius in blocks. 10000 blocks = 10 km.").defineInRange("rangeBlocks", 10000.0, 16.0, 30000.0);
        LINK_RANGE = b.defineInRange("linkRangeBlocks", 128, 4, 1024);
        b.pop();
        SPEC = b.build();
    }

    private VlsConfig() {}
}
